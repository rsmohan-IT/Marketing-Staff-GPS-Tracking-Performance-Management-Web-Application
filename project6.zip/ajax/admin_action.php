<?php
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'get_live_locations':
        // Get the latest location for all staff who have tracked points today
        $sql = "SELECT lt.user_id, lt.latitude, lt.longitude, lt.timestamp, u.name 
                FROM live_tracking lt
                JOIN users u ON lt.user_id = u.id
                INNER JOIN (
                    SELECT user_id, MAX(timestamp) as max_ts 
                    FROM live_tracking 
                    WHERE DATE(timestamp) = CURDATE()
                    GROUP BY user_id
                ) latest ON lt.user_id = latest.user_id AND lt.timestamp = latest.max_ts
                WHERE DATE(lt.timestamp) = CURDATE()";

        $stmt = $pdo->query($sql);
        $locations = $stmt->fetchAll();

        // Format last_seen
        foreach ($locations as &$loc) {
            $loc['last_seen'] = date('h:i:s A', strtotime($loc['timestamp']));
        }

        echo json_encode(['success' => true, 'locations' => $locations]);
        break;

    case 'get_route_history':
        $user_id = $_GET['user_id'] ?? null;
        $date = $_GET['date'] ?? date('Y-m-d');

        if (!$user_id) {
            echo json_encode(['success' => false, 'message' => 'User ID missing']);
            break;
        }

        $stmt = $pdo->prepare("SELECT latitude, longitude, timestamp FROM live_tracking WHERE user_id = ? AND DATE(timestamp) = ? ORDER BY timestamp ASC");
        $stmt->execute([$user_id, $date]);
        $points = $stmt->fetchAll();

        echo json_encode(['success' => true, 'points' => $points]);
        break;

    case 'update_report_status':
        $report_id = $_POST['id'] ?? null;
        $status = $_POST['status'] ?? null;

        if ($report_id && $status) {
            $stmt = $pdo->prepare("UPDATE daily_reports SET status = ? WHERE id = ?");
            if ($stmt->execute([$status, $report_id])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false]);
            }
        }
        break;

    case 'delete_staff':
        $user_id = $_POST['id'] ?? null;
        if ($user_id) {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'marketing'");
            if ($stmt->execute([$user_id])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false]);
            }
        }
        break;

    case 'toggle_staff_status':
        $user_id = $_POST['id'] ?? null;
        if ($user_id) {
            $stmt = $pdo->prepare("UPDATE users SET status = IF(status='active', 'inactive', 'active') WHERE id = ? AND role = 'marketing'");
            if ($stmt->execute([$user_id])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false]);
            }
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
