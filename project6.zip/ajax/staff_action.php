<?php
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$action = $_POST['action'] ?? '';
$user_id = $_SESSION['user_id'];
$lat = $_POST['lat'] ?? null;
$lng = $_POST['lng'] ?? null;

switch ($action) {
    case 'checkin':
        // Check if already checked in
        $stmt = $pdo->prepare("SELECT id FROM attendance WHERE user_id = ? AND DATE(check_in_time) = ? AND check_out_time IS NULL");
        $stmt->execute([$user_id, date('Y-m-d')]);
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Already checked in']);
            break;
        }

        $stmt = $pdo->prepare("INSERT INTO attendance (user_id, check_in_time, check_in_lat, check_in_long) VALUES (?, NOW(), ?, ?)");
        if ($stmt->execute([$user_id, $lat, $lng])) {
            // Also add to live tracking
            $stmt = $pdo->prepare("INSERT INTO live_tracking (user_id, latitude, longitude) VALUES (?, ?, ?)");
            $stmt->execute([$user_id, $lat, $lng]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Database error']);
        }
        break;

    case 'checkout':
        // Get check-in record
        $stmt = $pdo->prepare("SELECT * FROM attendance WHERE user_id = ? AND check_out_time IS NULL ORDER BY check_in_time DESC LIMIT 1");
        $stmt->execute([$user_id]);
        $row = $stmt->fetch();

        if ($row) {
            $check_in_lat = $row['check_in_lat'];
            $check_in_long = $row['check_in_long'];

            // Calculate total distance (simplified: start to end + intermediary path could be complex, 
            // but for simplicity we calculate sum of segments in live_tracking)

            $stmtDist = $pdo->prepare("SELECT latitude, longitude FROM live_tracking WHERE user_id = ? AND timestamp >= ?");
            $stmtDist->execute([$user_id, $row['check_in_time']]);
            $points = $stmtDist->fetchAll();

            $total_dist = 0;
            for ($i = 0; $i < count($points) - 1; $i++) {
                $total_dist += calculateDistance($points[$i]['latitude'], $points[$i]['longitude'], $points[$i + 1]['latitude'], $points[$i + 1]['longitude']);
            }

            // Calculate time
            $check_out_time = date('Y-m-d H:i:s');
            $diff = strtotime($check_out_time) - strtotime($row['check_in_time']);
            $hours = floor($diff / 3600);
            $mins = floor(($diff - ($hours * 3600)) / 60);
            $formatted_time = $hours . "h " . $mins . "m";

            $stmt = $pdo->prepare("UPDATE attendance SET check_out_time = NOW(), check_out_lat = ?, check_out_long = ?, total_distance = ?, total_time = ? WHERE id = ?");
            $stmt->execute([$lat, $lng, $total_dist, $formatted_time, $row['id']]);

            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'No active session found']);
        }
        break;

    case 'update_location':
        if ($lat && $lng) {
            $stmt = $pdo->prepare("INSERT INTO live_tracking (user_id, latitude, longitude) VALUES (?, ?, ?)");
            $stmt->execute([$user_id, $lat, $lng]);
            echo json_encode(['success' => true]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
