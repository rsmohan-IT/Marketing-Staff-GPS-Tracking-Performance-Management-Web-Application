<?php
// admin/includes/header.php
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/functions.php';
requireAdmin();

$page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | GPS Tracking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
</head>

<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0 fw-bold"><i class="fas fa-map-marked-alt me-2"></i>TRACKLY</h4>
            <small class="opacity-75">Admin Panel</small>
        </div>
        <div class="nav flex-column mt-4">
            <a href="dashboard.php" class="nav-link <?php echo $page == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
            <a href="live_tracking.php" class="nav-link <?php echo $page == 'live_tracking.php' ? 'active' : ''; ?>">
                <i class="fas fa-satellite"></i> Live Tracking
            </a>
            <a href="route_history.php" class="nav-link <?php echo $page == 'route_history.php' ? 'active' : ''; ?>">
                <i class="fas fa-history"></i> Route History
            </a>
            <a href="analytics.php" class="nav-link <?php echo $page == 'analytics.php' ? 'active' : ''; ?>">
                <i class="fas fa-chart-pie"></i> Performance
            </a>
            <a href="reports.php" class="nav-link <?php echo $page == 'reports.php' ? 'active' : ''; ?>">
                <i class="fas fa-file-invoice"></i> Daily Reports
            </a>
            <a href="staff_management.php" class="nav-link <?php echo $page == 'staff_management.php' ? 'active' : ''; ?>">
                <i class="fas fa-users"></i> Manage Staff
            </a>
            <div class="mt-auto mb-4">
                <a href="../logout.php" class="nav-link text-warning">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4" data-aos="fade-down">
            <div>
                <h3 class="fw-bold mb-0 text-primary-emphasis"><?php
                                                                $titles = [
                                                                    'dashboard.php' => 'Dashboard Overview',
                                                                    'live_tracking.php' => 'Live Staff Tracking',
                                                                    'route_history.php' => 'Route History Map',
                                                                    'analytics.php' => 'Performance Analytics',
                                                                    'reports.php' => 'Visit Reports',
                                                                    'staff_management.php' => 'Staff Management',
                                                                    'profile.php' => 'My Profile'
                                                                ];
                                                                echo $titles[$page] ?? 'Control Panel';
                                                                ?></h3>
                <p class="text-muted small"><?php echo date('l, d M Y'); ?></p>
            </div>
            <div class="d-flex align-items-center">
                <div class="bg-white p-2 rounded-circle shadow-sm me-3" style="width: 45px; height: 45px; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-bell text-primary"></i>
                </div>
                <div class="dropdown">
                    <div class="d-flex align-items-center bg-white p-1 pe-3 rounded-pill shadow-sm" style="cursor: pointer;" data-bs-toggle="dropdown">
                        <img src="https://ui-avatars.com/api/?name=Admin+User&background=667eea&color=fff" class="rounded-circle me-2" width="35">
                        <span class="small fw-bold"><?php echo $_SESSION['name']; ?></span>
                    </div>
                    <ul class="dropdown-menu dropdown-menu-end border-0 shadow mt-2 rounded-4">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-cog me-2"></i> Profile</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>