<?php
include 'includes/header.php';

// Productivity Score Calculation Logic
// Productivity = (Visits × 10) + (Distance × 2)
$sql = "SELECT u.name, 
        COUNT(DISTINCT a.id) as working_days,
        SUM(a.total_distance) as total_km,
        (SELECT COUNT(*) FROM daily_reports r WHERE r.user_id = u.id) as total_visits
        FROM users u
        LEFT JOIN attendance a ON u.id = a.user_id
        WHERE u.role = 'marketing'
        GROUP BY u.id";

$stats = $pdo->query($sql)->fetchAll();

foreach ($stats as &$s) {
    $s['score'] = ($s['total_visits'] * 10) + ($s['total_km'] * 2);
}

// Sort by score
usort($stats, function ($a, $b) {
    return $b['score'] <=> $a['score'];
});

$chart_labels = json_encode(array_column($stats, 'name'));
$chart_scores = json_encode(array_column($stats, 'score'));
?>

<div class="row g-4 mb-4">
    <div class="col-md-8">
        <div class="glass-card p-4">
            <h5 class="fw-bold mb-4">Productivity Ranking</h5>
            <div style="height: 350px; position: relative;">
                <canvas id="rankingChart"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-4" data-aos="fade-left">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-4">Top Performer</h5>
            <?php if (!empty($stats)): ?>
                <div class="text-center">
                    <div class="position-relative d-inline-block mb-3">
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($stats[0]['name']); ?>&size=100" class="rounded-circle shadow" width="100">
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-warning text-dark p-2 border border-white">
                            <i class="fas fa-crown"></i>
                        </span>
                    </div>
                    <h4 class="fw-bold"><?php echo $stats[0]['name']; ?></h4>
                    <p class="text-muted">Marketing Champion</p>
                    <div class="bg-light rounded-4 p-3 mt-3">
                        <div class="row">
                            <div class="col-6 border-end">
                                <h5 class="fw-bold text-primary mb-0"><?php echo $stats[0]['total_visits']; ?></h5>
                                <small class="text-muted">Visits</small>
                            </div>
                            <div class="col-6">
                                <h5 class="fw-bold text-success mb-0"><?php echo number_format($stats[0]['total_km'], 1); ?></h5>
                                <small class="text-muted">KM</small>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <p class="text-center text-muted">No data available.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-12" data-aos="fade-up">
        <div class="glass-card p-4">
            <h5 class="fw-bold mb-4">Staff metrics Overview</h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="bg-light">
                        <tr>
                            <th>Staff Name</th>
                            <th>Working Days</th>
                            <th>Distance Travelled</th>
                            <th>Client Visits</th>
                            <th>Productivity Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stats as $s): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($s['name']); ?>" class="rounded-circle me-2" width="30">
                                        <span><?php echo $s['name']; ?></span>
                                    </div>
                                </td>
                                <td><?php echo $s['working_days']; ?></td>
                                <td><?php echo number_format($s['total_km'], 1); ?> KM</td>
                                <td><?php echo $s['total_visits']; ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="progress flex-grow-1 me-2" style="height: 8px;">
                                            <div class="progress-bar bg-primary rounded-pill" style="width: <?php echo min(100, $s['score']); ?>%"></div>
                                        </div>
                                        <span class="fw-bold"><?php echo number_format($s['score'], 0); ?></span>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctxRank = document.getElementById('rankingChart');
        if (ctxRank) {
            new Chart(ctxRank, {
                type: 'bar',
                data: {
                    labels: <?php echo $chart_labels; ?>,
                    datasets: [{
                        label: 'Productivity Score',
                        data: <?php echo $chart_scores; ?>,
                        backgroundColor: 'rgba(102, 126, 234, 0.6)',
                        borderColor: '#667eea',
                        borderWidth: 1,
                        borderRadius: 10
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                display: false
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        }
    });
</script>

<?php include 'includes/footer.php'; ?>