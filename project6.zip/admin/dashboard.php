<?php
include 'includes/header.php';

// Fetch Statistics
$total_staff = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'marketing'")->fetchColumn();
$present_today = $pdo->query("SELECT COUNT(DISTINCT user_id) FROM attendance WHERE DATE(check_in_time) = CURDATE()")->fetchColumn();
$live_on_field = $pdo->query("SELECT COUNT(DISTINCT user_id) FROM attendance WHERE DATE(check_in_time) = CURDATE() AND check_out_time IS NULL")->fetchColumn();
$total_visits = $pdo->query("SELECT COUNT(*) FROM daily_reports WHERE DATE(created_at) = CURDATE()")->fetchColumn();

// Fetch Recent Activities
$recent_reports = $pdo->query("SELECT r.*, u.name as staff_name FROM daily_reports r JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC LIMIT 5")->fetchAll();

// Fetch Performance Data (Last 7 Days)
$perf_data = [];
$perf_labels = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $perf_labels[] = date('D', strtotime($date));

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM daily_reports WHERE DATE(created_at) = ?");
    $stmt->execute([$date]);
    $perf_data[] = $stmt->fetchColumn();
}
$perf_labels_json = json_encode($perf_labels);
$perf_data_json = json_encode($perf_data);
?>

<div class="row g-4 mb-4">
    <!-- Stat Cards -->
    <div class="col-md-3" data-aos="zoom-in" data-aos-delay="100">
        <div class="stat-card glass-card h-100" style="background: var(--primary-gradient);">
            <i class="fas fa-users"></i>
            <h6 class="opacity-75">Total Staff</h6>
            <h2 class="fw-bold"><?php echo $total_staff; ?></h2>
        </div>
    </div>
    <div class="col-md-3" data-aos="zoom-in" data-aos-delay="200">
        <div class="stat-card glass-card h-100" style="background: var(--success-gradient);">
            <i class="fas fa-user-check"></i>
            <h6 class="opacity-75">Present Today</h6>
            <h2 class="fw-bold"><?php echo $present_today; ?></h2>
        </div>
    </div>
    <div class="col-md-3" data-aos="zoom-in" data-aos-delay="300">
        <div class="stat-card glass-card h-100" style="background: var(--info-gradient);">
            <i class="fas fa-satellite-dish"></i>
            <h6 class="opacity-75">Live On Field</h6>
            <h2 class="fw-bold"><?php echo $live_on_field; ?></h2>
        </div>
    </div>
    <div class="col-md-3" data-aos="zoom-in" data-aos-delay="400">
        <div class="stat-card glass-card h-100" style="background: var(--warning-gradient);">
            <i class="fas fa-map-marker-alt"></i>
            <h6 class="opacity-75">Total Visits</h6>
            <h2 class="fw-bold"><?php echo $total_visits; ?></h2>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Charts Section -->
    <div class="col-md-8">
        <div class="glass-card p-4">
            <h5 class="fw-bold mb-4">Company Performance</h5>
            <div style="height: 300px; position: relative;">
                <canvas id="performanceChart"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="glass-card p-4">
            <h5 class="fw-bold mb-4">Attendance Ratio</h5>
            <div style="height: 300px; position: relative;">
                <canvas id="attendanceChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Recent Reports -->
    <div class="col-12" data-aos="fade-up">
        <div class="glass-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold mb-0">Recent Visit Reports</h5>
                <a href="reports.php" class="btn btn-sm btn-light rounded-pill px-3">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="bg-light">
                        <tr>
                            <th>Staff Name</th>
                            <th>Client</th>
                            <th>Value</th>
                            <th>Time</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_reports as $report): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($report['staff_name']); ?>" class="rounded-circle me-2" width="30">
                                        <span><?php echo $report['staff_name']; ?></span>
                                    </div>
                                </td>
                                <td><?php echo $report['client_name']; ?></td>
                                <td class="fw-bold">$<?php echo number_format($report['order_value'], 2); ?></td>
                                <td><?php echo date('h:i A', strtotime($report['created_at'])); ?></td>
                                <td>
                                    <span class="badge rounded-pill bg-<?php echo $report['status'] == 'approved' ? 'success' : ($report['status'] == 'rejected' ? 'danger' : 'warning'); ?> px-3">
                                        <?php echo ucfirst($report['status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($recent_reports)): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">No recent reports found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Performance Chart
        const ctxPerf = document.getElementById('performanceChart');
        if (ctxPerf) {
            new Chart(ctxPerf, {
                type: 'line',
                data: {
                    labels: <?php echo $perf_labels_json; ?>,
                    datasets: [{
                        label: 'Client Visits',
                        data: <?php echo $perf_data_json; ?>,
                        borderColor: '#667eea',
                        backgroundColor: 'rgba(102, 126, 234, 0.1)',
                        borderWidth: 3,
                        pointBackgroundColor: '#667eea',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                display: false
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        // Attendance Pie Chart
        const ctxAtt = document.getElementById('attendanceChart');
        if (ctxAtt) {
            new Chart(ctxAtt, {
                type: 'doughnut',
                data: {
                    labels: ['Present', 'Absent'],
                    datasets: [{
                        data: [<?php echo $present_today; ?>, <?php echo max(0, $total_staff - $present_today); ?>],
                        backgroundColor: ['#43e97b', '#f5576c'],
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '75%',
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
    });
</script>

<?php include 'includes/footer.php'; ?>