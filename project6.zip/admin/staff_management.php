<?php
include 'includes/header.php';

$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_staff'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    try {
        $stmt = $pdo->prepare("INSERT INTO users (name, email, mobile, password, role) VALUES (?, ?, ?, ?, 'marketing')");
        if ($stmt->execute([$name, $email, $mobile, $password])) {
            $msg = "Staff added successfully!";
        } else {
            $msg = "Error adding staff.";
        }
    } catch (PDOException $e) {
        $msg = "Error: " . $e->getMessage();
    }
}

$staff_list = $pdo->query("SELECT * FROM users WHERE role = 'marketing' ORDER BY created_at DESC")->fetchAll();
?>

<div class="row g-4" data-aos="fade-up">
    <div class="col-md-4">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-4">Add New Staff</h5>
            <?php if ($msg): ?>
                <div class="alert alert-info border-0 rounded-4"><?php echo $msg; ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-bold">FULL NAME</label>
                    <input type="text" name="name" class="form-control rounded-3 bg-light border-0" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">EMAIL ADDRESS</label>
                    <input type="email" name="email" class="form-control rounded-3 bg-light border-0" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">MOBILE NO</label>
                    <input type="text" name="mobile" class="form-control rounded-3 bg-light border-0" required>
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-bold">PASSWORD</label>
                    <input type="password" name="password" class="form-control rounded-3 bg-light border-0" required>
                </div>
                <button type="submit" name="add_staff" class="btn btn-premium w-100 py-3">
                    <i class="fas fa-user-plus me-2"></i> Register Staff
                </button>
            </form>
        </div>
    </div>

    <div class="col-md-8">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-4">Active Marketing Team</h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="bg-light">
                        <tr>
                            <th>Staff Name</th>
                            <th>Mobile</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($staff_list as $s): ?>
                            <tr id="staff-row-<?php echo $s['id']; ?>">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($s['name']); ?>" class="rounded-circle me-3" width="40">
                                        <div>
                                            <div class="fw-bold"><?php echo $s['name']; ?></div>
                                            <small class="text-muted"><?php echo $s['email']; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $s['mobile']; ?></td>
                                <td>
                                    <button class="btn btn-sm rounded-pill px-3 border-0 transition-all <?php echo $s['status'] == 'active' ? 'btn-success' : 'btn-secondary'; ?>" onclick="toggleStatus(<?php echo $s['id']; ?>)" id="status-btn-<?php echo $s['id']; ?>">
                                        <?php echo ucfirst($s['status']); ?>
                                    </button>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger rounded-circle border-0" onclick="deleteStaff(<?php echo $s['id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($staff_list)): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted">No staff found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleStatus(id) {
        if (!confirm("Change status for this staff?")) return;
        $.post('../ajax/admin_action.php', {
            action: 'toggle_staff_status',
            id: id
        }, function(res) {
            if (res.success) {
                const btn = $(`#status-btn-${id}`);
                const isActive = btn.text().trim().toLowerCase() === 'active';
                btn.text(isActive ? 'Inactive' : 'Active');
                btn.toggleClass('btn-success btn-secondary');
            } else {
                alert('Operation failed');
            }
        }, 'json');
    }

    function deleteStaff(id) {
        if (!confirm("Are you sure you want to delete this staff? All data including route history will be lost!")) return;
        $.post('../ajax/admin_action.php', {
            action: 'delete_staff',
            id: id
        }, function(res) {
            if (res.success) {
                $(`#staff-row-${id}`).fadeOut(300, function() {
                    $(this).remove();
                });
            } else {
                alert('Failed to delete staff member');
            }
        }, 'json');
    }
</script>

<?php include 'includes/footer.php'; ?>