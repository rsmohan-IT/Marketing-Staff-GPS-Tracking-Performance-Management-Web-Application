<?php
include 'includes/header.php';
?>

<style>
    #liveMap {
        height: 600px;
        border-radius: 20px;
        z-index: 1;
    }

    .staff-marker {
        border-radius: 50% !important;
        border: 2px solid white !important;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3) !important;
    }
</style>

<div class="row" data-aos="fade-up">
    <div class="col-12">
        <div class="glass-card mb-4">
            <div id="liveMap"></div>
        </div>
    </div>
</div>

<script>
    let map;
    let markers = {};

    function initMap() {
        map = L.map('liveMap').setView([20.5937, 78.9629], 5); // Default India center

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        updateMarkers();
        setInterval(updateMarkers, 10000); // 10 seconds interval
    }

    function updateMarkers() {
        $.getJSON('../ajax/admin_action.php?action=get_live_locations', function(data) {
            if (data.success) {
                const currentIds = data.locations.map(l => l.user_id);

                // Remove markers of users who are gone
                Object.keys(markers).forEach(id => {
                    if (!currentIds.includes(parseInt(id))) {
                        map.removeLayer(markers[id]);
                        delete markers[id];
                    }
                });

                data.locations.forEach(loc => {
                    const pos = [loc.latitude, loc.longitude];

                    if (markers[loc.user_id]) {
                        // Update position smoothly
                        markers[loc.user_id].setLatLng(pos);
                    } else {
                        // Create new marker
                        const marker = L.marker(pos, {
                            icon: L.divIcon({
                                className: 'custom-div-icon',
                                html: `<div class="bg-primary text-white rounded-circle shadow p-1" style="width: 40px; height: 40px; border: 2px solid white; overflow: hidden;"><img src="https://ui-avatars.com/api/?name=${encodeURIComponent(loc.name)}&size=40" class="rounded-circle w-100 h-100"></div>`,
                                iconSize: [40, 40],
                                iconAnchor: [20, 40]
                            })
                        }).addTo(map);

                        marker.bindPopup(`<b>${loc.name}</b><br>Last Updated: ${loc.last_seen}`);
                        markers[loc.user_id] = marker;
                    }
                });

                // Adjust view if first time or new staff added
                if (Object.keys(markers).length > 0) {
                    const group = new L.featureGroup(Object.values(markers));
                    if (map.getZoom() < 8) {
                        map.fitBounds(group.getBounds().pad(0.1));
                    }
                }
            }
        });
    }

    $(document).ready(function() {
        initMap();
    });
</script>

<?php include 'includes/footer.php'; ?>