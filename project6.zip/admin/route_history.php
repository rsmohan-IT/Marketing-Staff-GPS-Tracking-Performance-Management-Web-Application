<?php
include 'includes/header.php';

$staff_members = $pdo->query("SELECT id, name FROM users WHERE role = 'marketing'")->fetchAll();
?>

<style>
    #historyMap {
        height: 500px;
        border-radius: 20px;
        z-index: 1;
    }
</style>

<div class="row g-4">
    <div class="col-md-4" data-aos="fade-right">
        <div class="glass-card p-4 h-100">
            <h5 class="fw-bold mb-4">Select Route</h5>
            <form id="historyForm">
                <div class="mb-3">
                    <label class="form-label small fw-bold">STAFF MEMBER</label>
                    <select id="user_id" class="form-select rounded-3 bg-light border-0" required>
                        <option value="">Choose Staff...</option>
                        <?php foreach ($staff_members as $staff): ?>
                            <option value="<?php echo $staff['id']; ?>"><?php echo $staff['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-bold">SELECT DATE</label>
                    <input type="date" id="historyDate" class="form-control rounded-3 bg-light border-0" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                <button type="submit" class="btn btn-premium w-100 py-3">
                    <i class="fas fa-search me-2"></i> View History
                </button>
            </form>

            <div id="routeStats" class="mt-4 d-none" data-aos="fade-up">
                <hr>
                <div class="text-center">
                    <h2 class="fw-bold mb-0 text-primary" id="statDistance">0.0</h2>
                    <small class="text-muted text-uppercase fw-bold">Total Kilometers</small>
                </div>
                <div class="d-flex justify-content-between mt-3 px-2">
                    <div class="text-center">
                        <small class="d-block text-muted">First Activity</small>
                        <span class="fw-bold" id="statStart">--:--</span>
                    </div>
                    <div class="text-center">
                        <small class="d-block text-muted">Last Activity</small>
                        <span class="fw-bold" id="statEnd">--:--</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-8" data-aos="fade-left">
        <div class="glass-card overflow-hidden h-100">
            <div id="historyMap"></div>
        </div>
    </div>
</div>

<script>
    let map;
    let pathLayer;
    let markerLayer;

    function initMap() {
        map = L.map('historyMap').setView([20.5937, 78.9629], 5);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        pathLayer = L.featureGroup().addTo(map);
        markerLayer = L.featureGroup().addTo(map);
    }

    $('#historyForm').submit(function(e) {
        e.preventDefault();
        const userId = $('#user_id').val();
        const date = $('#historyDate').val();

        $.getJSON(`../ajax/admin_action.php?action=get_route_history&user_id=${userId}&date=${date}`, function(data) {
            pathLayer.clearLayers();
            markerLayer.clearLayers();

            if (data.success && data.points.length > 0) {
                const points = data.points;
                const latlngs = points.map(p => [p.latitude, p.longitude]);

                // Draw path
                const polyline = L.polyline(latlngs, {
                    color: '#764ba2',
                    weight: 5,
                    opacity: 0.7
                }).addTo(pathLayer);

                // Add Start/End markers
                L.marker(latlngs[0]).addTo(markerLayer).bindPopup(`Start: ${new Date(points[0].timestamp).toLocaleTimeString()}`);
                L.marker(latlngs[latlngs.length - 1]).addTo(markerLayer).bindPopup(`End: ${new Date(points[points.length - 1].timestamp).toLocaleTimeString()}`);

                map.fitBounds(pathLayer.getBounds().pad(0.1));

                // Stats
                $('#routeStats').removeClass('d-none');
                $('#statStart').text(new Date(points[0].timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit'
                }));
                $('#statEnd').text(new Date(points[points.length - 1].timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit'
                }));

                // Simplified distance calculation for UI
                let dist = 0;
                for (let i = 0; i < latlngs.length - 1; i++) {
                    dist += map.distance(latlngs[i], latlngs[i + 1]);
                }
                $('#statDistance').text((dist / 1000).toFixed(2));

            } else {
                alert('No movement data found for this date.');
                $('#routeStats').addClass('d-none');
            }
        });
    });

    $(document).ready(function() {
        initMap();
    });
</script>

<?php include 'includes/footer.php'; ?>