<?php
include 'includes/header.php';

$reports = $pdo->query("SELECT r.*, u.name as staff_name FROM daily_reports r JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC")->fetchAll();
?>

<div class="row" data-aos="fade-up">
    <div class="col-12">
        <div class="glass-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold mb-0">Daily Visit Reports</h5>
                <div>
                    <button class="btn btn-sm btn-outline-success rounded-pill px-3 me-2" onclick="exportToExcel()">
                        <i class="fas fa-file-excel me-1"></i> Excel
                    </button>
                    <button class="btn btn-sm btn-outline-secondary rounded-pill px-3" onclick="window.print()">
                        <i class="fas fa-print me-1"></i> Print
                    </button>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle" id="reportsTable">
                    <thead class="bg-light">
                        <tr>
                            <th>Staff Info</th>
                            <th>Visit Information</th>
                            <th>Order Value</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reports as $r): ?>
                            <tr id="report-row-<?php echo $r['id']; ?>">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($r['staff_name']); ?>" class="rounded-circle me-2" width="35">
                                        <div>
                                            <div class="fw-bold"><?php echo $r['staff_name']; ?></div>
                                            <small class="text-muted"><?php echo date('d M, h:i A', strtotime($r['created_at'])); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?php echo $r['client_name']; ?></div>
                                    <small class="text-muted d-block" style="max-width: 250px;"><?php echo $r['summary']; ?></small>
                                </td>
                                <td class="fw-bold text-success">$<?php echo number_format($r['order_value'], 2); ?></td>
                                <td>
                                    <a href="https://www.google.com/maps?q=<?php echo $r['latitude']; ?>,<?php echo $r['longitude']; ?>" target="_blank" class="btn btn-sm btn-outline-info rounded-pill">
                                        <i class="fas fa-map-pin me-1"></i> View
                                    </a>
                                </td>
                                <td>
                                    <span class="badge rounded-pill bg-<?php echo $r['status'] == 'approved' ? 'success' : ($r['status'] == 'rejected' ? 'danger' : 'warning'); ?> px-3" id="status-badge-<?php echo $r['id']; ?>">
                                        <?php echo ucfirst($r['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-success rounded-start-pill border-0" onclick="updateStatus(<?php echo $r['id']; ?>, 'approved')">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger rounded-end-pill border-0" onclick="updateStatus(<?php echo $r['id']; ?>, 'rejected')">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($reports)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">No reports submitted yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function exportToExcel() {
        let table = document.getElementById("reportsTable");
        let html = table.outerHTML;
        let url = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
        let link = document.createElement("a");
        link.download = "visit_reports.xls";
        link.href = url;
        link.click();
    }

    function updateStatus(id, status) {
        $.post('../ajax/admin_action.php', {
            action: 'update_report_status',
            id: id,
            status: status
        }, function(res) {
            if (res.success) {
                const badge = $(`#status-badge-${id}`);
                badge.text(status.charAt(0).toUpperCase() + status.slice(1));
                badge.removeClass('bg-warning bg-success bg-danger');
                badge.addClass(status === 'approved' ? 'bg-success' : 'bg-danger');
            } else {
                alert('Failed to update status');
            }
        }, 'json');
    }
</script>

<?php include 'includes/footer.php'; ?>