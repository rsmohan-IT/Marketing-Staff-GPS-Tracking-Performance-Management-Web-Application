<?php
include 'includes/header.php';

$user_id = $_SESSION['user_id'];
$success_msg = "";
$error_msg = "";

// Fetch current user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $new_password = $_POST['new_password'];

    try {
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET name = ?, mobile = ?, password = ? WHERE id = ?");
            $stmt->execute([$name, $mobile, $hashed_password, $user_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, mobile = ? WHERE id = ?");
            $stmt->execute([$name, $mobile, $user_id]);
        }

        $_SESSION['name'] = $name;
        $success_msg = "Profile updated successfully!";

        // Refresh user data
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
    } catch (Exception $e) {
        $error_msg = "Update failed: " . $e->getMessage();
    }
}
?>

<div class="row" data-aos="fade-up">
    <div class="col-md-8 mx-auto">
        <div class="glass-card p-4">
            <div class="d-flex align-items-center mb-4">
                <div class="position-relative me-4">
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['name']); ?>&size=120&background=667eea&color=fff" class="rounded-circle shadow-lg border border-white border-4" width="120">
                    <div class="position-absolute bottom-0 end-0 bg-success border border-white border-2 rounded-circle p-2 shadow-sm"></div>
                </div>
                <div>
                    <h3 class="fw-bold mb-1"><?php echo $user['name']; ?></h3>
                    <p class="text-muted"><i class="fas fa-shield-alt me-2"></i>System Administrator</p>
                    <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill px-3">Active Account</span>
                </div>
            </div>

            <hr class="opacity-10 mb-4">

            <?php if ($success_msg): ?>
                <div class="alert alert-success border-0 rounded-4 mb-4" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $success_msg; ?>
                </div>
            <?php endif; ?>

            <?php if ($error_msg): ?>
                <div class="alert alert-danger border-0 rounded-4 mb-4" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error_msg; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">FULL NAME</label>
                        <input type="text" name="name" class="form-control rounded-3 bg-light border-0 py-2 px-3" value="<?php echo $user['name']; ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">MOBILE NUMBER</label>
                        <input type="text" name="mobile" class="form-control rounded-3 bg-light border-0 py-2 px-3" value="<?php echo $user['mobile']; ?>" required>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label fw-bold small">EMAIL ADDRESS (LOGIN)</label>
                        <input type="email" class="form-control rounded-3 bg-light border-0 py-2 px-3" value="<?php echo $user['email']; ?>" disabled>
                        <small class="text-muted">Email address cannot be changed for security reasons.</small>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label fw-bold small">CHANGE PASSWORD</label>
                        <input type="password" name="new_password" class="form-control rounded-3 bg-light border-0 py-2 px-3" placeholder="Enter new password to change">
                        <small class="text-muted">Leave empty if you don't want to change the password.</small>
                    </div>
                    <div class="col-12 mt-4 text-end">
                        <button type="submit" name="update_profile" class="btn btn-premium px-5 py-2 shadow-sm rounded-pill">
                            <i class="fas fa-save me-2"></i> Update Admin Profile
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>