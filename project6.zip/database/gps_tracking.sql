-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2026 at 01:46 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gps_tracking`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `check_in_time` datetime NOT NULL,
  `check_out_time` datetime DEFAULT NULL,
  `check_in_lat` decimal(10,8) NOT NULL,
  `check_in_long` decimal(11,8) NOT NULL,
  `check_out_lat` decimal(10,8) DEFAULT NULL,
  `check_out_long` decimal(11,8) DEFAULT NULL,
  `total_distance` decimal(10,2) DEFAULT 0.00,
  `total_time` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `user_id`, `check_in_time`, `check_out_time`, `check_in_lat`, `check_in_long`, `check_out_lat`, `check_out_long`, `total_distance`, `total_time`) VALUES
(1, 2, '2026-02-19 10:22:00', '2026-02-19 17:23:00', 12.98760000, 77.55660000, 13.01660000, 77.54060000, 41.00, '8h 32m'),
(2, 2, '2026-02-18 09:37:00', '2026-02-18 18:47:00', 13.02560000, 77.50360000, 12.90360000, 77.55460000, 10.00, '8h 5m'),
(3, 2, '2026-02-17 10:55:00', '2026-02-17 18:28:00', 12.89160000, 77.58060000, 12.89660000, 77.53360000, 39.00, '8h 47m'),
(4, 2, '2026-02-16 09:58:00', '2026-02-16 18:18:00', 12.99260000, 77.55660000, 12.89960000, 77.56260000, 24.00, '8h 53m'),
(5, 2, '2026-02-15 09:46:00', '2026-02-15 18:43:00', 13.04660000, 77.67960000, 12.97360000, 77.55360000, 19.00, '8h 25m'),
(6, 2, '2026-02-14 10:21:00', '2026-02-14 17:34:00', 12.97660000, 77.54760000, 13.05760000, 77.67760000, 22.00, '8h 31m'),
(7, 2, '2026-02-13 10:01:00', '2026-02-13 18:41:00', 12.92360000, 77.64560000, 12.87160000, 77.69160000, 13.00, '8h 19m'),
(8, 3, '2026-02-19 10:01:00', '2026-02-19 18:10:00', 12.90660000, 77.58260000, 12.94260000, 77.59360000, 34.00, '8h 32m'),
(9, 3, '2026-02-18 09:52:00', '2026-02-18 18:38:00', 12.89960000, 77.51760000, 13.03060000, 77.55760000, 10.00, '8h 38m'),
(10, 3, '2026-02-17 09:33:00', '2026-02-17 18:25:00', 12.90860000, 77.68660000, 13.04060000, 77.68660000, 34.00, '8h 13m'),
(11, 3, '2026-02-16 10:08:00', '2026-02-16 17:08:00', 12.92360000, 77.54860000, 12.94960000, 77.59860000, 50.00, '8h 25m'),
(12, 3, '2026-02-15 10:19:00', '2026-02-15 18:38:00', 13.04360000, 77.66260000, 12.88860000, 77.59760000, 37.00, '8h 49m'),
(13, 3, '2026-02-14 10:46:00', '2026-02-14 18:16:00', 13.01960000, 77.54160000, 12.99760000, 77.59660000, 20.00, '8h 59m'),
(14, 3, '2026-02-13 10:45:00', '2026-02-13 18:58:00', 12.94060000, 77.65460000, 13.04760000, 77.62860000, 25.00, '8h 52m'),
(15, 4, '2026-02-19 09:40:00', '2026-02-19 18:35:00', 13.06260000, 77.67060000, 13.01760000, 77.63860000, 16.00, '8h 59m'),
(16, 4, '2026-02-18 10:41:00', '2026-02-18 18:50:00', 12.87660000, 77.55660000, 12.93560000, 77.51460000, 50.00, '8h 41m'),
(17, 4, '2026-02-17 10:30:00', '2026-02-17 18:46:00', 12.87960000, 77.68660000, 12.93360000, 77.67060000, 31.00, '8h 46m'),
(18, 4, '2026-02-16 09:00:00', '2026-02-16 17:25:00', 13.02460000, 77.63860000, 13.04160000, 77.59560000, 29.00, '8h 29m'),
(19, 4, '2026-02-15 10:10:00', '2026-02-15 17:10:00', 12.88660000, 77.50760000, 13.00560000, 77.66160000, 27.00, '8h 25m'),
(20, 4, '2026-02-14 10:37:00', '2026-02-14 17:39:00', 12.90260000, 77.68260000, 12.89660000, 77.61760000, 33.00, '8h 52m'),
(21, 4, '2026-02-13 10:13:00', '2026-02-13 18:56:00', 13.03960000, 77.52560000, 12.89660000, 77.54960000, 26.00, '8h 22m'),
(22, 5, '2026-02-19 10:56:00', '2026-02-19 17:40:00', 12.87260000, 77.51360000, 12.91460000, 77.63060000, 40.00, '8h 29m'),
(23, 5, '2026-02-18 09:26:00', '2026-02-18 17:05:00', 13.01360000, 77.57260000, 13.05260000, 77.57360000, 18.00, '8h 17m'),
(24, 5, '2026-02-17 10:46:00', '2026-02-17 17:00:00', 13.06760000, 77.54860000, 12.89760000, 77.62560000, 40.00, '8h 30m'),
(25, 5, '2026-02-16 09:09:00', '2026-02-16 18:19:00', 12.96160000, 77.62660000, 13.02560000, 77.66060000, 26.00, '8h 41m'),
(26, 5, '2026-02-15 10:40:00', '2026-02-15 18:12:00', 12.97560000, 77.59760000, 12.99960000, 77.50360000, 21.00, '8h 22m'),
(27, 5, '2026-02-14 09:39:00', '2026-02-14 17:08:00', 13.00060000, 77.51660000, 13.03460000, 77.58160000, 16.00, '8h 27m'),
(28, 5, '2026-02-13 10:29:00', '2026-02-13 17:43:00', 12.89860000, 77.57560000, 12.94060000, 77.52560000, 14.00, '8h 42m'),
(29, 6, '2026-02-19 09:17:00', '2026-02-19 17:03:00', 13.04560000, 77.56960000, 13.05460000, 77.66160000, 18.00, '8h 28m'),
(30, 6, '2026-02-18 10:44:00', '2026-02-18 18:08:00', 13.03460000, 77.66460000, 12.96160000, 77.66760000, 10.00, '8h 52m'),
(31, 6, '2026-02-17 09:09:00', '2026-02-17 17:18:00', 12.87260000, 77.60460000, 12.90960000, 77.65960000, 38.00, '8h 42m'),
(32, 6, '2026-02-16 10:39:00', '2026-02-16 17:13:00', 12.95360000, 77.56560000, 12.93560000, 77.55760000, 12.00, '8h 32m'),
(33, 6, '2026-02-15 09:00:00', '2026-02-15 17:39:00', 12.99460000, 77.68960000, 12.94560000, 77.57060000, 34.00, '8h 30m'),
(34, 6, '2026-02-14 10:54:00', '2026-02-14 18:05:00', 13.00360000, 77.60060000, 12.99960000, 77.51460000, 48.00, '8h 23m'),
(35, 6, '2026-02-13 10:09:00', '2026-02-13 18:34:00', 12.93460000, 77.50660000, 12.93860000, 77.65360000, 40.00, '8h 30m'),
(36, 11, '2026-02-19 17:57:00', '2026-02-19 18:15:41', 11.66996770, 78.14327590, 11.66999940, 78.14329630, 0.00, '-5h 48m');

-- --------------------------------------------------------

--
-- Table structure for table `daily_reports`
--

CREATE TABLE `daily_reports` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `summary` text NOT NULL,
  `order_value` decimal(10,2) DEFAULT 0.00,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `daily_reports`
--

INSERT INTO `daily_reports` (`id`, `user_id`, `client_name`, `latitude`, `longitude`, `summary`, `order_value`, `image`, `status`, `created_at`) VALUES
(1, 2, 'Zenith Logistics', 12.97760000, 77.53260000, 'Routine visit to Zenith Logistics for product demonstration.', 3968.00, NULL, 'approved', '2026-02-19 05:55:00'),
(2, 2, 'Oceanic Exports', 12.89560000, 77.64160000, 'Routine visit to Oceanic Exports for product demonstration.', 4655.00, NULL, 'approved', '2026-02-19 09:59:00'),
(3, 2, 'Zenith Logistics', 12.92460000, 77.51360000, 'Routine visit to Zenith Logistics for product demonstration.', 4304.00, NULL, 'approved', '2026-02-18 10:12:00'),
(4, 2, 'Global Tech Solutions', 12.92660000, 77.58760000, 'Routine visit to Global Tech Solutions for product demonstration.', 2799.00, NULL, 'approved', '2026-02-17 09:51:00'),
(5, 2, 'Oceanic Exports', 12.88860000, 77.56660000, 'Routine visit to Oceanic Exports for product demonstration.', 2575.00, NULL, 'approved', '2026-02-17 11:13:00'),
(6, 2, 'Sunrise Enterprises', 12.96360000, 77.56560000, 'Routine visit to Sunrise Enterprises for product demonstration.', 3793.00, NULL, 'approved', '2026-02-17 08:01:00'),
(7, 2, 'Sunrise Enterprises', 12.94560000, 77.58960000, 'Routine visit to Sunrise Enterprises for product demonstration.', 3150.00, NULL, 'approved', '2026-02-16 06:47:00'),
(8, 2, 'Zenith Logistics', 13.04960000, 77.66860000, 'Routine visit to Zenith Logistics for product demonstration.', 4723.00, NULL, 'approved', '2026-02-16 10:05:00'),
(9, 2, 'City Retail Hub', 12.93160000, 77.50460000, 'Routine visit to City Retail Hub for product demonstration.', 1390.00, NULL, 'approved', '2026-02-16 08:52:00'),
(10, 2, 'Oceanic Exports', 13.04760000, 77.59760000, 'Routine visit to Oceanic Exports for product demonstration.', 903.00, NULL, 'approved', '2026-02-15 07:48:00'),
(11, 2, 'Zenith Logistics', 12.96660000, 77.65760000, 'Routine visit to Zenith Logistics for product demonstration.', 4308.00, NULL, 'approved', '2026-02-15 07:45:00'),
(12, 2, 'Oceanic Exports', 12.90560000, 77.59660000, 'Routine visit to Oceanic Exports for product demonstration.', 964.00, NULL, 'approved', '2026-02-15 07:26:00'),
(13, 2, 'Global Tech Solutions', 12.90960000, 77.52960000, 'Routine visit to Global Tech Solutions for product demonstration.', 1063.00, NULL, 'approved', '2026-02-14 07:10:00'),
(14, 2, 'Zenith Logistics', 12.94160000, 77.68660000, 'Routine visit to Zenith Logistics for product demonstration.', 1425.00, NULL, 'approved', '2026-02-13 08:18:00'),
(15, 2, 'Sunrise Enterprises', 12.90160000, 77.66260000, 'Routine visit to Sunrise Enterprises for product demonstration.', 3178.00, NULL, 'approved', '2026-02-13 09:52:00'),
(16, 3, 'Zenith Logistics', 13.06360000, 77.66760000, 'Routine visit to Zenith Logistics for product demonstration.', 4780.00, NULL, 'approved', '2026-02-19 09:40:00'),
(17, 3, 'Oceanic Exports', 13.02060000, 77.54760000, 'Routine visit to Oceanic Exports for product demonstration.', 2537.00, NULL, 'approved', '2026-02-19 05:58:00'),
(18, 3, 'Global Tech Solutions', 12.93760000, 77.60360000, 'Routine visit to Global Tech Solutions for product demonstration.', 3625.00, NULL, 'approved', '2026-02-19 10:50:00'),
(19, 3, 'Apex Manufacturing', 12.97060000, 77.50160000, 'Routine visit to Apex Manufacturing for product demonstration.', 4090.00, NULL, 'approved', '2026-02-18 05:44:00'),
(20, 3, 'Oceanic Exports', 12.91060000, 77.64260000, 'Routine visit to Oceanic Exports for product demonstration.', 606.00, NULL, 'approved', '2026-02-17 06:16:00'),
(21, 3, 'Global Tech Solutions', 13.00660000, 77.68960000, 'Routine visit to Global Tech Solutions for product demonstration.', 3362.00, NULL, 'approved', '2026-02-16 06:04:00'),
(22, 3, 'Zenith Logistics', 12.97460000, 77.57160000, 'Routine visit to Zenith Logistics for product demonstration.', 3007.00, NULL, 'approved', '2026-02-15 09:44:00'),
(23, 3, 'Apex Manufacturing', 13.03460000, 77.58760000, 'Routine visit to Apex Manufacturing for product demonstration.', 4872.00, NULL, 'approved', '2026-02-15 08:08:00'),
(24, 3, 'Sunrise Enterprises', 13.00260000, 77.56560000, 'Routine visit to Sunrise Enterprises for product demonstration.', 951.00, NULL, 'approved', '2026-02-15 10:12:00'),
(25, 3, 'Global Tech Solutions', 13.00760000, 77.63260000, 'Routine visit to Global Tech Solutions for product demonstration.', 2915.00, NULL, 'approved', '2026-02-14 06:46:00'),
(26, 3, 'Sunrise Enterprises', 12.94060000, 77.58860000, 'Routine visit to Sunrise Enterprises for product demonstration.', 4132.00, NULL, 'approved', '2026-02-13 07:02:00'),
(27, 3, 'Oceanic Exports', 13.03460000, 77.61860000, 'Routine visit to Oceanic Exports for product demonstration.', 4731.00, NULL, 'approved', '2026-02-13 06:47:00'),
(28, 3, 'Sunrise Enterprises', 13.05360000, 77.56660000, 'Routine visit to Sunrise Enterprises for product demonstration.', 3437.00, NULL, 'approved', '2026-02-13 06:57:00'),
(29, 4, 'Zenith Logistics', 13.02760000, 77.56460000, 'Routine visit to Zenith Logistics for product demonstration.', 4300.00, NULL, 'approved', '2026-02-19 05:48:00'),
(30, 4, 'Apex Manufacturing', 12.96160000, 77.58360000, 'Routine visit to Apex Manufacturing for product demonstration.', 4851.00, NULL, 'approved', '2026-02-19 06:04:00'),
(31, 4, 'Zenith Logistics', 12.90060000, 77.54660000, 'Routine visit to Zenith Logistics for product demonstration.', 3985.00, NULL, 'approved', '2026-02-19 08:58:00'),
(32, 4, 'Apex Manufacturing', 12.94260000, 77.65960000, 'Routine visit to Apex Manufacturing for product demonstration.', 3935.00, NULL, 'approved', '2026-02-18 10:45:00'),
(33, 4, 'Apex Manufacturing', 12.96460000, 77.62060000, 'Routine visit to Apex Manufacturing for product demonstration.', 919.00, NULL, 'approved', '2026-02-17 11:18:00'),
(34, 4, 'Zenith Logistics', 13.00060000, 77.60960000, 'Routine visit to Zenith Logistics for product demonstration.', 3749.00, NULL, 'approved', '2026-02-17 11:22:00'),
(35, 4, 'Zenith Logistics', 12.96460000, 77.64060000, 'Routine visit to Zenith Logistics for product demonstration.', 4123.00, NULL, 'approved', '2026-02-16 06:51:00'),
(36, 4, 'Sunrise Enterprises', 12.97460000, 77.62560000, 'Routine visit to Sunrise Enterprises for product demonstration.', 2364.00, NULL, 'approved', '2026-02-15 07:21:00'),
(37, 4, 'Oceanic Exports', 12.91760000, 77.67360000, 'Routine visit to Oceanic Exports for product demonstration.', 2035.00, NULL, 'approved', '2026-02-15 07:57:00'),
(38, 4, 'Sunrise Enterprises', 13.03960000, 77.58560000, 'Routine visit to Sunrise Enterprises for product demonstration.', 819.00, NULL, 'approved', '2026-02-15 06:00:00'),
(39, 4, 'City Retail Hub', 13.04660000, 77.60860000, 'Routine visit to City Retail Hub for product demonstration.', 4693.00, NULL, 'approved', '2026-02-14 08:55:00'),
(40, 4, 'City Retail Hub', 12.93360000, 77.69360000, 'Routine visit to City Retail Hub for product demonstration.', 2844.00, NULL, 'approved', '2026-02-13 09:14:00'),
(41, 4, 'Oceanic Exports', 12.97460000, 77.69360000, 'Routine visit to Oceanic Exports for product demonstration.', 680.00, NULL, 'approved', '2026-02-13 09:28:00'),
(42, 5, 'City Retail Hub', 12.94260000, 77.51060000, 'Routine visit to City Retail Hub for product demonstration.', 1874.00, NULL, 'approved', '2026-02-19 09:42:00'),
(43, 5, 'Sunrise Enterprises', 13.00360000, 77.67360000, 'Routine visit to Sunrise Enterprises for product demonstration.', 3655.00, NULL, 'approved', '2026-02-19 07:25:00'),
(44, 5, 'Oceanic Exports', 12.88160000, 77.49960000, 'Routine visit to Oceanic Exports for product demonstration.', 606.00, NULL, 'approved', '2026-02-19 07:07:00'),
(45, 5, 'City Retail Hub', 12.89560000, 77.55260000, 'Routine visit to City Retail Hub for product demonstration.', 1079.00, NULL, 'approved', '2026-02-18 10:50:00'),
(46, 5, 'Apex Manufacturing', 12.98960000, 77.65960000, 'Routine visit to Apex Manufacturing for product demonstration.', 1480.00, NULL, 'approved', '2026-02-18 08:48:00'),
(47, 5, 'Oceanic Exports', 12.90160000, 77.63760000, 'Routine visit to Oceanic Exports for product demonstration.', 4179.00, NULL, 'approved', '2026-02-18 07:28:00'),
(48, 5, 'City Retail Hub', 12.87860000, 77.60560000, 'Routine visit to City Retail Hub for product demonstration.', 599.00, NULL, 'approved', '2026-02-17 10:23:00'),
(49, 5, 'Apex Manufacturing', 12.87960000, 77.67360000, 'Routine visit to Apex Manufacturing for product demonstration.', 1025.00, NULL, 'approved', '2026-02-16 06:43:00'),
(50, 5, 'City Retail Hub', 12.87460000, 77.58360000, 'Routine visit to City Retail Hub for product demonstration.', 3646.00, NULL, 'approved', '2026-02-16 08:55:00'),
(51, 5, 'Oceanic Exports', 12.90560000, 77.63760000, 'Routine visit to Oceanic Exports for product demonstration.', 3713.00, NULL, 'approved', '2026-02-16 08:02:00'),
(52, 5, 'Apex Manufacturing', 12.87260000, 77.58760000, 'Routine visit to Apex Manufacturing for product demonstration.', 2247.00, NULL, 'approved', '2026-02-15 05:58:00'),
(53, 5, 'Oceanic Exports', 12.90260000, 77.52160000, 'Routine visit to Oceanic Exports for product demonstration.', 4937.00, NULL, 'approved', '2026-02-15 05:40:00'),
(54, 5, 'Sunrise Enterprises', 12.95760000, 77.54060000, 'Routine visit to Sunrise Enterprises for product demonstration.', 2250.00, NULL, 'approved', '2026-02-15 06:27:00'),
(55, 5, 'Global Tech Solutions', 12.88760000, 77.51160000, 'Routine visit to Global Tech Solutions for product demonstration.', 2785.00, NULL, 'approved', '2026-02-14 11:28:00'),
(56, 5, 'Zenith Logistics', 12.89660000, 77.61660000, 'Routine visit to Zenith Logistics for product demonstration.', 1530.00, NULL, 'approved', '2026-02-14 07:28:00'),
(57, 5, 'City Retail Hub', 12.91360000, 77.55260000, 'Routine visit to City Retail Hub for product demonstration.', 4033.00, NULL, 'approved', '2026-02-13 09:13:00'),
(58, 5, 'Zenith Logistics', 13.01160000, 77.68260000, 'Routine visit to Zenith Logistics for product demonstration.', 2335.00, NULL, 'approved', '2026-02-13 09:57:00'),
(59, 6, 'Apex Manufacturing', 12.87560000, 77.50460000, 'Routine visit to Apex Manufacturing for product demonstration.', 2552.00, NULL, 'approved', '2026-02-19 07:03:00'),
(60, 6, 'Oceanic Exports', 12.87760000, 77.50360000, 'Routine visit to Oceanic Exports for product demonstration.', 1809.00, NULL, 'approved', '2026-02-19 06:23:00'),
(61, 6, 'Global Tech Solutions', 12.92260000, 77.61760000, 'Routine visit to Global Tech Solutions for product demonstration.', 2148.00, NULL, 'approved', '2026-02-19 08:16:00'),
(62, 6, 'Sunrise Enterprises', 12.90660000, 77.68860000, 'Routine visit to Sunrise Enterprises for product demonstration.', 4752.00, NULL, 'approved', '2026-02-18 10:56:00'),
(63, 6, 'Apex Manufacturing', 13.04260000, 77.53260000, 'Routine visit to Apex Manufacturing for product demonstration.', 531.00, NULL, 'approved', '2026-02-18 07:15:00'),
(64, 6, 'City Retail Hub', 12.87560000, 77.57260000, 'Routine visit to City Retail Hub for product demonstration.', 3280.00, NULL, 'approved', '2026-02-17 08:40:00'),
(65, 6, 'Apex Manufacturing', 13.06060000, 77.57660000, 'Routine visit to Apex Manufacturing for product demonstration.', 2189.00, NULL, 'approved', '2026-02-17 11:14:00'),
(66, 6, 'Apex Manufacturing', 13.05060000, 77.52060000, 'Routine visit to Apex Manufacturing for product demonstration.', 3147.00, NULL, 'approved', '2026-02-16 07:40:00'),
(67, 6, 'Sunrise Enterprises', 12.94860000, 77.60460000, 'Routine visit to Sunrise Enterprises for product demonstration.', 2508.00, NULL, 'approved', '2026-02-16 07:28:00'),
(68, 6, 'Oceanic Exports', 13.04660000, 77.52960000, 'Routine visit to Oceanic Exports for product demonstration.', 848.00, NULL, 'approved', '2026-02-16 09:50:00'),
(69, 6, 'City Retail Hub', 13.04160000, 77.64960000, 'Routine visit to City Retail Hub for product demonstration.', 1761.00, NULL, 'approved', '2026-02-15 10:27:00'),
(70, 6, 'City Retail Hub', 12.99360000, 77.52760000, 'Routine visit to City Retail Hub for product demonstration.', 2081.00, NULL, 'approved', '2026-02-15 08:53:00'),
(71, 6, 'Zenith Logistics', 12.94060000, 77.49460000, 'Routine visit to Zenith Logistics for product demonstration.', 1011.00, NULL, 'approved', '2026-02-14 08:20:00'),
(72, 6, 'Global Tech Solutions', 13.06360000, 77.57260000, 'Routine visit to Global Tech Solutions for product demonstration.', 4828.00, NULL, 'approved', '2026-02-14 10:04:00'),
(73, 6, 'Oceanic Exports', 13.04260000, 77.66060000, 'Routine visit to Oceanic Exports for product demonstration.', 2685.00, NULL, 'approved', '2026-02-14 06:15:00'),
(74, 6, 'Oceanic Exports', 12.99760000, 77.50460000, 'Routine visit to Oceanic Exports for product demonstration.', 3916.00, NULL, 'approved', '2026-02-13 06:12:00'),
(75, 6, 'Global Tech Solutions', 12.92660000, 77.53260000, 'Routine visit to Global Tech Solutions for product demonstration.', 3125.00, NULL, 'approved', '2026-02-13 11:20:00'),
(76, 6, 'Sunrise Enterprises', 13.04460000, 77.68060000, 'Routine visit to Sunrise Enterprises for product demonstration.', 924.00, NULL, 'approved', '2026-02-13 07:29:00'),
(77, 11, 'Suresh', 11.66995090, 78.14343760, 'CCTV Installation', 10000.00, NULL, 'pending', '2026-02-19 12:42:48');

-- --------------------------------------------------------

--
-- Table structure for table `live_tracking`
--

CREATE TABLE `live_tracking` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `live_tracking`
--

INSERT INTO `live_tracking` (`id`, `user_id`, `latitude`, `longitude`, `timestamp`) VALUES
(1, 2, 13.01560000, 77.59560000, '2026-02-19 12:20:58'),
(2, 3, 12.98660000, 77.64160000, '2026-02-19 12:20:58'),
(3, 4, 12.99160000, 77.59560000, '2026-02-19 12:20:58'),
(4, 5, 12.98460000, 77.59860000, '2026-02-19 12:20:58'),
(5, 6, 13.01560000, 77.55260000, '2026-02-19 12:20:58'),
(6, 11, 11.66996770, 78.14327590, '2026-02-19 12:27:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','marketing') NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `mobile`, `email`, `password`, `role`, `status`, `created_at`) VALUES
(1, 'Admin User', '1234567890', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', '2026-02-19 11:59:54'),
(2, 'Marketing Staff 1', '9876543210', 'staff@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'marketing', 'active', '2026-02-19 11:59:54'),
(3, 'Rahul Sharma', '9876543210', 'rahul@example.com', '$2y$10$fv/GpIh6jKEnILxVL8Q1UOZx5XUqEGD8lacGt52W8Msb1gM5ywzsa', 'marketing', 'active', '2026-02-19 12:20:40'),
(4, 'Priya Patel', '9876543211', 'priya@example.com', '$2y$10$Jf3K9vhT05tKwuSsvHM9leoHKTolQDRDHbN/AK8M2yceW/u6uDkp.', 'marketing', 'active', '2026-02-19 12:20:40'),
(5, 'Arun Kumar', '9876543212', 'arun@example.com', '$2y$10$snMoJgm5Bbba5pGtIhm3zuFk2niUtkb/4XxsyX5dNdY1RXxZv7mEG', 'marketing', 'active', '2026-02-19 12:20:40'),
(6, 'Sneha Reddy', '9876543213', 'sneha@example.com', '$2y$10$G5.JZIWqawGS5r8.d61e4eERjsXN4VvHfSslXVkYPvDmiaYRvBhgG', 'marketing', 'active', '2026-02-19 12:20:40'),
(11, 'Mohan', '9994285228', 'rsmohanmsg91@gmail.com', '$2y$10$nuXZIRSivKo3u3WiocSJc.oqkmvdpkCfHAgp9UB72KCgzLgmrPIM.', 'marketing', 'active', '2026-02-19 12:24:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `daily_reports`
--
ALTER TABLE `daily_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `live_tracking`
--
ALTER TABLE `live_tracking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `daily_reports`
--
ALTER TABLE `daily_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `live_tracking`
--
ALTER TABLE `live_tracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `daily_reports`
--
ALTER TABLE `daily_reports`
  ADD CONSTRAINT `daily_reports_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `live_tracking`
--
ALTER TABLE `live_tracking`
  ADD CONSTRAINT `live_tracking_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
