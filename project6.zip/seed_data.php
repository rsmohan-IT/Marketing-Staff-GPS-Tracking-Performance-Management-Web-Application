<?php
require_once 'config/db.php';

echo "<h2>Populating Sample Data...</h2>";

try {
    // 1. Add more Staff Members
    $staff_data = [
        ['Rahul Sharma', 'rahul@example.com', '9876543210', password_hash('staff123', PASSWORD_DEFAULT)],
        ['Priya Patel', 'priya@example.com', '9876543211', password_hash('staff123', PASSWORD_DEFAULT)],
        ['Arun Kumar', 'arun@example.com', '9876543212', password_hash('staff123', PASSWORD_DEFAULT)],
        ['Sneha Reddy', 'sneha@example.com', '9876543213', password_hash('staff123', PASSWORD_DEFAULT)]
    ];

    $stmt = $pdo->prepare("INSERT IGNORE INTO users (name, email, mobile, password, role) VALUES (?, ?, ?, ?, 'marketing')");
    foreach ($staff_data as $staff) {
        $stmt->execute($staff);
    }
    echo "Done: Staff Members added.<br>";

    // Get all staff IDs
    $staff_ids = $pdo->query("SELECT id FROM users WHERE role = 'marketing'")->fetchAll(PDO::FETCH_COLUMN);

    // 2. Add Sample Attendance & Daily Reports for the last 7 days
    $clients = ['Global Tech Solutions', 'City Retail Hub', 'Apex Manufacturing', 'Sunrise Enterprises', 'Zenith Logistics', 'Oceanic Exports'];

    foreach ($staff_ids as $uid) {
        for ($i = 0; $i < 7; $i++) {
            $date = date('Y-m-d', strtotime("-$i days"));
            $check_in = "$date " . str_pad(rand(9, 10), 2, '0', STR_PAD_LEFT) . ":" . str_pad(rand(0, 59), 2, '0', STR_PAD_LEFT) . ":00";
            $check_out = "$date " . str_pad(rand(17, 18), 2, '0', STR_PAD_LEFT) . ":" . str_pad(rand(0, 59), 2, '0', STR_PAD_LEFT) . ":00";

            // Attendance
            $stmt = $pdo->prepare("INSERT INTO attendance (user_id, check_in_time, check_out_time, check_in_lat, check_in_long, check_out_lat, check_out_long, total_distance, total_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $uid,
                $check_in,
                $check_out,
                12.9716 + (rand(-100, 100) / 1000),
                77.5946 + (rand(-100, 100) / 1000),
                12.9716 + (rand(-100, 100) / 1000),
                77.5946 + (rand(-100, 100) / 1000),
                rand(10, 50),
                "8h " . rand(0, 59) . "m"
            ]);

            // Daily Reports (1-3 visits per day)
            $visits = rand(1, 3);
            for ($v = 0; $v < $visits; $v++) {
                $client = $clients[array_rand($clients)];
                $val = rand(500, 5000);
                $report_time = "$date " . str_pad(rand(11, 16), 2, '0', STR_PAD_LEFT) . ":" . rand(10, 59) . ":00";

                $stmt = $pdo->prepare("INSERT INTO daily_reports (user_id, client_name, summary, order_value, latitude, longitude, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'approved', ?)");
                $stmt->execute([
                    $uid,
                    $client,
                    "Routine visit to $client for product demonstration.",
                    $val,
                    12.9716 + (rand(-100, 100) / 1000),
                    77.5946 + (rand(-100, 100) / 1000),
                    $report_time
                ]);
            }
        }
    }
    echo "Done: Attendance and Daily Reports populated.<br>";

    // 3. Add Live Tracking Points for today
    foreach ($staff_ids as $uid) {
        $stmt = $pdo->prepare("INSERT INTO live_tracking (user_id, latitude, longitude, timestamp) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$uid, 12.9716 + (rand(-50, 50) / 1000), 77.5946 + (rand(-50, 50) / 1000)]);
    }
    echo "Done: Live Tracking data updated.<br>";

    echo "<h3 style='color: green;'>Sample data population complete!</h3>";
} catch (PDOException $e) {
    echo "<h3 style='color: red;'>Error: " . $e->getMessage() . "</h3>";
}
