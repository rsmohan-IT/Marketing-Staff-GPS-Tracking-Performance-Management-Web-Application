<?php
include 'includes/header.php';

$user_id = $_SESSION['user_id'];
$today = date('Y-m-d');

// Fetch today's coordinates
$stmt = $pdo->prepare("SELECT latitude, longitude, timestamp FROM live_tracking WHERE user_id = ? AND DATE(timestamp) = ? ORDER BY timestamp ASC");
$stmt->execute([$user_id, $today]);
$points = $stmt->fetchAll();

$json_points = json_encode($points);
?>

<style>
    #map {
        height: 400px;
        border-radius: 20px;
        z-index: 1;
    }
</style>

<div class="row" data-aos="fade-up">
    <div class="col-12 mb-4">
        <div class="glass-card overflow-hidden">
            <div id="map"></div>
        </div>
    </div>

    <div class="col-12" data-aos="fade-up" data-aos-delay="200">
        <div class="glass-card p-4">
            <h6 class="fw-bold mb-3"><i class="fas fa-chart-line me-2 text-primary"></i>Today's Route Stats</h6>
            <div class="list-group list-group-flush">
                <div class="list-group-item bg-transparent d-flex justify-content-between align-items-center px-0">
                    <span class="text-muted">Total Points Logged</span>
                    <span class="fw-bold"><?php echo count($points); ?></span>
                </div>
                <div class="list-group-item bg-transparent d-flex justify-content-between align-items-center px-0">
                    <span class="text-muted">First Log</span>
                    <span class="fw-bold"><?php echo count($points) > 0 ? date("h:i A", strtotime($points[0]['timestamp'])) : 'N/A'; ?></span>
                </div>
                <div class="list-group-item bg-transparent d-flex justify-content-between align-items-center px-0 border-0">
                    <span class="text-muted">Last Log</span>
                    <span class="fw-bold"><?php echo count($points) > 0 ? date("h:i A", strtotime(end($points)['timestamp'])) : 'N/A'; ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        const points = <?php echo $json_points; ?>;

        if (points.length > 0) {
            const map = L.map('map').setView([points[0].latitude, points[0].longitude], 15);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);

            const latlngs = points.map(p => [p.latitude, p.longitude]);

            // Draw path
            const polyline = L.polyline(latlngs, {
                color: '#764ba2',
                weight: 5,
                opacity: 0.7
            }).addTo(map);

            // Add markers for Start and End
            L.marker(latlngs[0]).addTo(map).bindPopup('Start Point').openPopup();
            if (latlngs.length > 1) {
                L.marker(latlngs[latlngs.length - 1]).addTo(map).bindPopup('Current/Last Point');
            }

            // Zoom map to fit the path
            map.fitBounds(polyline.getBounds());
        } else {
            $('#map').html('<div class="h-100 d-flex align-items-center justify-content-center text-muted">No route data for today yet.</div>');
        }
    });
</script>

<?php include 'includes/footer.php'; ?>