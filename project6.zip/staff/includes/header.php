<?php
// staff/includes/header.php
require_once '../config/db.php';
require_once '../includes/session.php';
require_once '../includes/functions.php';
requireStaff();

$page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard | GPS Tracking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <style>
        .staff-header {
            background: var(--primary-gradient);
            color: white;
            padding: 1.5rem;
            border-radius: 0 0 30px 30px;
            margin-bottom: 2rem;
        }
    </style>
</head>

<body>
    <div class="main-content-staff bg-light min-vh-100 pb-5">
        <div class="staff-header d-flex justify-content-between align-items-center" data-aos="fade-down">
            <div>
                <h5 class="mb-0 fw-bold">Hello, <?php echo $_SESSION['name']; ?> 👋</h5>
                <small class="opacity-75">Marketing Staff</small>
            </div>
            <a href="../logout.php" class="text-white bg-white bg-opacity-25 rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
        <div class="container pb-5">