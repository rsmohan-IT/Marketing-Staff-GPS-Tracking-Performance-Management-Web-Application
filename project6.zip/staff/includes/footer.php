        </div><!-- container -->
        </div><!-- main-content-staff -->

        <!-- Bottom Navigation for Staff -->
        <div class="bottom-nav">
            <a href="dashboard.php" class="<?php echo $page == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i>
                <span>Home</span>
            </a>
            <a href="my_route.php" class="<?php echo $page == 'my_route.php' ? 'active' : ''; ?>">
                <i class="fas fa-route"></i>
                <span>Route</span>
            </a>
            <a href="report.php" class="<?php echo $page == 'report.php' ? 'active' : ''; ?>">
                <i class="fas fa-file-alt"></i>
                <span>Report</span>
            </a>
            <a href="history.php" class="<?php echo $page == 'history.php' ? 'active' : ''; ?>">
                <i class="fas fa-history"></i>
                <span>History</span>
            </a>
            <a href="profile.php" class="<?php echo $page == 'profile.php' ? 'active' : ''; ?>">
                <i class="fas fa-user"></i>
                <span>Profile</span>
            </a>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script>
            AOS.init({
                duration: 800,
                once: true
            });
        </script>
        </body>

        </html>