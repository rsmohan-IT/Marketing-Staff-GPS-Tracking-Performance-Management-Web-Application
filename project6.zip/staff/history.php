<?php
include 'includes/header.php';

$user_id = $_SESSION['user_id'];
$attendance_history = $pdo->prepare("SELECT * FROM attendance WHERE user_id = ? ORDER BY check_in_time DESC LIMIT 10");
$attendance_history->execute([$user_id]);
$history = $attendance_history->fetchAll();
?>

<div class="row" data-aos="fade-up">
    <div class="col-12">
        <div class="glass-card p-4">
            <h5 class="fw-bold mb-4"><i class="fas fa-history me-2 text-primary"></i>My Recent Activity</h5>

            <div class="timeline">
                <?php foreach ($history as $h): ?>
                    <div class="mb-4 pb-3 border-bottom position-relative">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold"><?php echo date('D, d M Y', strtotime($h['check_in_time'])); ?></span>
                            <span class="badge rounded-pill bg-success px-3">Completed</span>
                        </div>
                        <div class="row g-2 text-muted small">
                            <div class="col-6">
                                <i class="fas fa-clock me-1"></i> In: <?php echo date('h:i A', strtotime($h['check_in_time'])); ?>
                            </div>
                            <div class="col-6 text-end">
                                <i class="fas fa-clock me-1"></i> Out: <?php echo $h['check_out_time'] ? date('h:i A', strtotime($h['check_out_time'])) : 'N/A'; ?>
                            </div>
                            <div class="col-6">
                                <i class="fas fa-walking me-1"></i> <?php echo number_format($h['total_distance'], 2); ?> KM
                            </div>
                            <div class="col-6 text-end">
                                <i class="fas fa-hourglass-half me-1"></i> <?php echo $h['total_time']; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if (empty($history)): ?>
                    <p class="text-center text-muted">No history found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>