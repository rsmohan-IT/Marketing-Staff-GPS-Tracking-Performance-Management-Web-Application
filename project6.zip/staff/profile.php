<?php
include 'includes/header.php';

$user_id = $_SESSION['user_id'];
$success_msg = "";
$error_msg = "";

// Fetch current user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $new_password = $_POST['new_password'];

    try {
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET name = ?, mobile = ?, password = ? WHERE id = ?");
            $stmt->execute([$name, $mobile, $hashed_password, $user_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, mobile = ? WHERE id = ?");
            $stmt->execute([$name, $mobile, $user_id]);
        }

        $_SESSION['name'] = $name;
        $success_msg = "Profile updated successfully!";

        // Refresh user data
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
    } catch (Exception $e) {
        $error_msg = "Update failed: " . $e->getMessage();
    }
}
?>

<div class="row" data-aos="fade-up">
    <div class="col-12">
        <div class="glass-card p-4">
            <div class="text-center mb-4">
                <div class="position-relative d-inline-block">
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['name']); ?>&size=100&background=random" class="rounded-circle shadow border border-white border-4" width="100">
                    <span class="position-absolute bottom-0 end-0 bg-success border border-white border-2 rounded-circle" style="width: 15px; height: 15px;"></span>
                </div>
                <h4 class="fw-bold mt-3 mb-0"><?php echo $user['name']; ?></h4>
                <p class="text-muted small"><?php echo ucfirst($user['role']); ?> Member</p>
            </div>

            <?php if ($success_msg): ?>
                <div class="alert alert-success border-0 rounded-4 mb-4">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $success_msg; ?>
                </div>
            <?php endif; ?>

            <?php if ($error_msg): ?>
                <div class="alert alert-danger border-0 rounded-4 mb-4">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error_msg; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label fw-bold small">FULL NAME</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0 rounded-start-3"><i class="fas fa-user text-muted"></i></span>
                        <input type="text" name="name" class="form-control bg-light border-0 rounded-end-3" value="<?php echo $user['name']; ?>" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small">EMAIL ADDRESS</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0 rounded-start-3"><i class="fas fa-envelope text-muted"></i></span>
                        <input type="email" class="form-control bg-light border-0 rounded-end-3" value="<?php echo $user['email']; ?>" disabled>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small">MOBILE NUMBER</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0 rounded-start-3"><i class="fas fa-phone text-muted"></i></span>
                        <input type="text" name="mobile" class="form-control bg-light border-0 rounded-end-3" value="<?php echo $user['mobile']; ?>" required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold small text-primary">NEW PASSWORD (LEAVE BLANK TO KEEP CURRENT)</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0 rounded-start-3"><i class="fas fa-lock text-muted"></i></span>
                        <input type="password" name="new_password" class="form-control bg-light border-0 rounded-end-3" placeholder="••••••••">
                    </div>
                </div>

                <button type="submit" name="update_profile" class="btn btn-premium w-100 py-3 shadow">
                    <i class="fas fa-save me-2"></i> Save Profile Changes
                </button>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>