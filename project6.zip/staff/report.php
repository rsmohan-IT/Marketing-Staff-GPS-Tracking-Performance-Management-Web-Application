<?php
include 'includes/header.php';

$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_report'])) {
    $client_name = $_POST['client_name'];
    $summary = $_POST['summary'];
    $order_value = $_POST['order_value'];
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare("INSERT INTO daily_reports (user_id, client_name, summary, order_value, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt->execute([$user_id, $client_name, $summary, $order_value, $lat, $lng])) {
        $msg = "Report submitted successfully!";
    } else {
        $msg = "Error submitting report.";
    }
}
?>

<div class="row" data-aos="fade-up">
    <div class="col-12">
        <div class="glass-card p-4">
            <h5 class="fw-bold mb-4"><i class="fas fa-edit me-2 text-primary"></i>Daily Work Report</h5>

            <?php if ($msg): ?>
                <div class="alert alert-success border-0 rounded-4">
                    <?php echo $msg; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <input type="hidden" name="lat" id="report_lat">
                <input type="hidden" name="lng" id="report_lng">

                <div class="mb-3">
                    <label class="form-label fw-bold small">CLIENT NAME</label>
                    <input type="text" name="client_name" class="form-control rounded-3 bg-light border-0" placeholder="Enter client name" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small">ORDER VALUE ($)</label>
                    <input type="number" step="0.01" name="order_value" class="form-control rounded-3 bg-light border-0" placeholder="0.00">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small">MEETING SUMMARY</label>
                    <textarea name="summary" class="form-control rounded-3 bg-light border-0" rows="4" placeholder="Briefly describe the visit..." required></textarea>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold small">ATTACH PHOTO (Optional)</label>
                    <input type="file" name="image" class="form-control rounded-3 bg-light border-0">
                </div>

                <button type="submit" name="submit_report" class="btn btn-premium w-100 py-3">
                    <i class="fas fa-paper-plane me-2"></i> Submit Report
                </button>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                $('#report_lat').val(position.coords.latitude);
                $('#report_lng').val(position.coords.longitude);
            });
        }
    });
</script>

<?php include 'includes/footer.php'; ?>