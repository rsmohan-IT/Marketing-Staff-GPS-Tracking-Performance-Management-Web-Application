<?php
include 'includes/header.php';

// Check current status
$user_id = $_SESSION['user_id'];
$today = date('Y-m-d');
$stmt = $pdo->prepare("SELECT * FROM attendance WHERE user_id = ? AND DATE(check_in_time) = ? AND check_out_time IS NULL LIMIT 1");
$stmt->execute([$user_id, $today]);
$current_session = $stmt->fetch();

$is_checked_in = $current_session ? true : false;

// Fetch today's stats
$stmtStats = $pdo->prepare("SELECT SUM(total_distance) as dist, SEC_TO_TIME(SUM(TIME_TO_SEC(check_out_time) - TIME_TO_SEC(check_in_time))) as total_time FROM attendance WHERE user_id = ? AND DATE(check_in_time) = ?");
$stmtStats->execute([$user_id, $today]);
$stats = $stmtStats->fetch();

$today_km = number_format($stats['dist'] ?? 0, 1);
$today_hours = $stats['total_time'] ? date('H', strtotime($stats['total_time'])) . 'h' : '0h';
?>

<div class="row g-4 mb-4">
    <!-- Status Card -->
    <div class="col-12" data-aos="zoom-in">
        <div class="glass-card p-4 text-center">
            <h6 class="text-muted mb-3">CURRENT STATUS</h6>
            <?php if ($is_checked_in): ?>
                <div class="mb-3">
                    <span class="tracking-active"></span>
                    <span class="text-success fw-bold">Live Tracking Active</span>
                </div>
                <button id="checkoutBtn" class="btn btn-danger btn-lg rounded-pill px-5 shadow">
                    <i class="fas fa-stop-circle me-2"></i> Check-Out
                </button>
                <div class="mt-3">
                    <small class="text-muted">Started at: <?php echo date("h:i A", strtotime($current_session['check_in_time'])); ?></small>
                </div>
            <?php else: ?>
                <div class="mb-3">
                    <span class="text-muted fw-bold">Currently Offline</span>
                </div>
                <button id="checkinBtn" class="btn btn-premium btn-lg rounded-pill px-5 shadow">
                    <i class="fas fa-play-circle me-2"></i> Check-In
                </button>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-6" data-aos="fade-up" data-aos-delay="100">
        <div class="glass-card p-3 text-center" style="background: var(--info-gradient); color: white;">
            <i class="fas fa-walking mb-2 fs-3"></i>
            <h4 class="mb-0 fw-bold" id="todayDistance"><?php echo $today_km; ?></h4>
            <small>KM Today</small>
        </div>
    </div>
    <div class="col-6" data-aos="fade-up" data-aos-delay="200">
        <div class="glass-card p-3 text-center" style="background: var(--warning-gradient); color: white;">
            <i class="fas fa-clock mb-2 fs-3"></i>
            <h4 class="mb-0 fw-bold" id="workingHours"><?php echo $today_hours; ?></h4>
            <small>Duty Time</small>
        </div>
    </div>
</div>

<!-- Actions -->
<div class="row g-3">
    <div class="col-12" data-aos="fade-up">
        <div class="glass-card p-4">
            <h6 class="fw-bold mb-3"><i class="fas fa-plus-circle me-2 text-primary"></i>Quick Actions</h6>
            <div class="row g-2">
                <div class="col-6">
                    <a href="report.php" class="btn btn-light w-100 py-3 rounded-4 border">
                        <i class="fas fa-file-signature d-block mb-1 text-primary"></i>
                        <small>Submit Report</small>
                    </a>
                </div>
                <div class="col-6">
                    <a href="my_route.php" class="btn btn-light w-100 py-3 rounded-4 border">
                        <i class="fas fa-map-marked-alt d-block mb-1 text-success"></i>
                        <small>My Route</small>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let trackingInterval;

    $(document).ready(function() {
        <?php if ($is_checked_in): ?>
            startTracking();
        <?php endif; ?>

        $('#checkinBtn').click(function() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;

                    $.post('../ajax/staff_action.php', {
                        action: 'checkin',
                        lat: lat,
                        lng: lng
                    }, function(res) {
                        if (res.success) {
                            location.reload();
                        } else {
                            alert(res.message);
                        }
                    }, 'json');
                }, function(err) {
                    alert("Please enable GPS to check-in.");
                });
            }
        });

        $('#checkoutBtn').click(function() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;

                    $.post('../ajax/staff_action.php', {
                        action: 'checkout',
                        lat: lat,
                        lng: lng
                    }, function(res) {
                        if (res.success) {
                            stopTracking();
                            location.reload();
                        } else {
                            alert(res.message);
                        }
                    }, 'json');
                });
            }
        });
    });

    function startTracking() {
        console.log("Tracking started...");
        trackingInterval = setInterval(function() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;

                    $.post('../ajax/staff_action.php', {
                        action: 'update_location',
                        lat: lat,
                        lng: lng
                    });
                });
            }
        }, 30000); // 30 seconds
    }

    function stopTracking() {
        clearInterval(trackingInterval);
    }
</script>

<?php include 'includes/footer.php'; ?>